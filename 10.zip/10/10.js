document.addEventListener(("DOMContentLoaded", ()=>{
    const bt = document.querySelector("button");
    const number = document.querySelectorAll("#num");
    }
));

bt.addEventListener("click", ()=>{
    let n = Math.floor(Math.random() * 46) + 1;
    console.log("n=",n);

    document.querySelector(".num").innerHTML = `${n}`;
});